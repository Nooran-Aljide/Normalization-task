package com.progressoft.tools;

import java.nio.file.Path;
import java.nio.file.Paths;

public class Main {
    public static void main(String[] args) {

        // src/test/resources/employees.csv src/test/resources/results.csv  zscore salary
        String srcFilePath = args[0];
        String destFilePath = args[1];
        String normalizationType = args[2];
        String columnName = args[3];

        NormalizerClass normalizer = new NormalizerClass();

        Path srcPath = Paths.get(srcFilePath);
        Path destPath = Paths.get(destFilePath);
        switch (normalizationType){
            case "zscore":
                normalizer.zscore(srcPath, destPath, columnName);
                break;
            case "min-max":
                normalizer.minMaxScaling(srcPath, destPath,columnName);
                break;
            default:
                throw new IllegalArgumentException("Not available normalization type");
        }

    }
}
