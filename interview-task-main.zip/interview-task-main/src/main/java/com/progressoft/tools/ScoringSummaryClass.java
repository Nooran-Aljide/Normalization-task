package com.progressoft.tools;

import org.json.simple.JSONObject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;

public class ScoringSummaryClass implements ScoringSummary {

    Path srcCSVFilePath;
    Path destPath;
    String colName;

    public ScoringSummaryClass(Path csvPath, Path destPath, String colName) {
        this.srcCSVFilePath = csvPath;
        this.destPath = destPath;
        this.colName = colName;
    }

    public static JSONObject readCSV(Path srcFilePath, String colName) throws IOException {
        ArrayList<String[]> rows = new ArrayList<>();
        JSONObject result = new JSONObject();

        try {
            BufferedReader csvReader = new BufferedReader(new FileReader(String.valueOf(srcFilePath)));
            String line;
            while ((line = csvReader.readLine()) != null) {
                rows.add(line.split(","));
            }
            ArrayList<String> columnData = new ArrayList<>();
            int columnIndex = -1;
            if (Arrays.asList(rows.get(0)).contains(colName)) {
                result.put("allColumnsData", rows);
                columnIndex = Arrays.asList(rows.get(0)).indexOf(colName);
                result.put("columnIndex", columnIndex);
                for (int i = 0; i < rows.size(); i++) {
                    columnData.add(rows.get(i)[columnIndex]);
                }
                result.put("columnData", columnData);
                csvReader.close();
            } else {
                csvReader.close();
                throw new IllegalArgumentException("column "+colName+" not found");
            }
        } catch (IOException e) {
            throw new IllegalArgumentException("source file not found");
        }

        return result;
    }

    public static void writeCSV(String row, Path destFilePth) throws IOException {
        try {
            FileWriter csvWriter = new FileWriter(String.valueOf(destFilePth), true);
            csvWriter.append(String.valueOf(row));
            csvWriter.append("\n");
            csvWriter.flush();
            csvWriter.close();
        } catch (IOException e) {
            throw new IllegalArgumentException("source file not found");
        }
    }

    @Override
    public BigDecimal mean() {
        BigDecimal mean;
        BigDecimal count = new BigDecimal(0);
        BigDecimal sum = new BigDecimal(0);
        try {
            JSONObject result = readCSV(srcCSVFilePath, colName);
            ArrayList<String> columnData = (ArrayList<String>) result.get("columnData");

            for (int i = 1; i < columnData.size(); i++) {
                count = count.add(new BigDecimal(1));
                sum = sum.add(BigDecimal.valueOf((Double.parseDouble(columnData.get(i)))));
            }
            mean = sum.divide(count, 0, RoundingMode.HALF_EVEN);

        } catch (IOException e) {
            throw new IllegalArgumentException("failed to read data - mean");
        }


        return mean.setScale(2, RoundingMode.HALF_EVEN);
    }

    @Override
    public BigDecimal standardDeviation() {
        BigDecimal SD = new BigDecimal(0);
        BigDecimal count = new BigDecimal(0);
        BigDecimal mean = mean();

        try {
            JSONObject result = readCSV(srcCSVFilePath, colName);
            ArrayList<String> columnData = (ArrayList<String>) result.get("columnData");

            MathContext mc = new MathContext(4);
            double value;
            for (int i = 1; i < columnData.size(); i++) {
                count = count.add(new BigDecimal(1));
                value = Double.parseDouble(columnData.get(i));
                SD = SD.add(BigDecimal.valueOf(Math.ceil(Math.pow(((BigDecimal.valueOf(value).subtract(mean, mc)).doubleValue()), 2))));
            }
        } catch (IOException e) {
            throw new IllegalArgumentException("failed to read data - SD");
        }
        BigDecimal x = SD.divide(count, 2, RoundingMode.HALF_EVEN);
        BigDecimal y = BigDecimal.valueOf(Math.sqrt((x.doubleValue())));
        BigDecimal finalSD = y.divide(new BigDecimal(1), 2, RoundingMode.CEILING);
        return finalSD;
    }

    @Override
    public BigDecimal variance() {
        BigDecimal x = BigDecimal.valueOf((Math.pow(standardDeviation().doubleValue(), 2)));
        x = x.setScale(0, RoundingMode.HALF_EVEN);
        BigDecimal variance = x.divide(new BigDecimal(1), 2, RoundingMode.HALF_EVEN);
        return variance;
    }

    @Override
    public BigDecimal median() {
        try {
            JSONObject result = readCSV(srcCSVFilePath, colName);
            ArrayList<String> columnData = (ArrayList<String>) result.get("columnData");

            double[] sortedValues = new double[columnData.size() - 1];
            for (int i = 1; i < columnData.size(); i++) {
                sortedValues[i - 1] = Double.parseDouble(columnData.get(i));
            }

            Arrays.sort(sortedValues);
            BigDecimal middle;

            if (sortedValues.length % 2 == 0) {
                middle = BigDecimal.valueOf(sortedValues[sortedValues.length / 2] + sortedValues[(sortedValues.length - 1) / 2]);
                BigDecimal m = middle.divide(new BigDecimal(2), 2, RoundingMode.HALF_EVEN);
                return middle.divide(new BigDecimal(2), 2, RoundingMode.HALF_EVEN);
            } else {
                middle = BigDecimal.valueOf(sortedValues[sortedValues.length / 2]);
                return middle.divide(new BigDecimal(1), 2, RoundingMode.HALF_EVEN);
            }

        } catch (IOException e) {
            throw new IllegalArgumentException("failed to read data - median");

        }
    }

    @Override
    public BigDecimal min() {
        try {
            JSONObject result = readCSV(srcCSVFilePath, colName);
            ArrayList<String> columnData = (ArrayList<String>) result.get("columnData");

            double[] sortedValues = new double[columnData.size() - 1];
            for (int i = 1; i < columnData.size(); i++) {
                sortedValues[i - 1] = Double.parseDouble(columnData.get(i));
            }
            Arrays.sort(sortedValues);

            BigDecimal min = BigDecimal.valueOf(sortedValues[0]);
            return min.divide(new BigDecimal(1), 2, RoundingMode.HALF_EVEN);
        } catch (IOException e) {
            throw new IllegalArgumentException("failed to read data - min");
        }
    }

    @Override
    public BigDecimal max() {
        try {
            JSONObject result = readCSV(srcCSVFilePath, colName);
            ArrayList<String> columnData = (ArrayList<String>) result.get("columnData");

            double[] sortedValues = new double[columnData.size() - 1];
            for (int i = 1; i < columnData.size(); i++) {
                sortedValues[i - 1] = Double.parseDouble(columnData.get(i));
            }
            Arrays.sort(sortedValues);

            BigDecimal max = BigDecimal.valueOf(sortedValues[sortedValues.length - 1]);
            return max.divide(new BigDecimal(1), 2, RoundingMode.HALF_EVEN);
        } catch (IOException e) {
            throw new IllegalArgumentException("failed to read data - max");
        }
    }
}
