package com.progressoft.tools;

import org.json.simple.JSONObject;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;

import static com.progressoft.tools.ScoringSummaryClass.readCSV;
import static com.progressoft.tools.ScoringSummaryClass.writeCSV;

public class NormalizerClass implements Normalizer {

    @Override
    public ScoringSummary zscore(Path csvPath, Path destPath, String colToNormalize) {

        ScoringSummary scoringSummary = new ScoringSummaryClass(csvPath, destPath, colToNormalize);
        try {
            JSONObject result = readCSV(csvPath, colToNormalize);
            ArrayList<String> columnData = (ArrayList<String>) result.get("columnData");
            ArrayList<String[]> allColumnsData = ((ArrayList<String[]>) result.get("allColumnsData"));
            String[] CSVFileHeader = allColumnsData.get(0);
            int columnIndex = (int) result.get("columnIndex");

            // create csv file new header
            ArrayList<String> header = new ArrayList<>(Arrays.asList(CSVFileHeader));
            header.add(columnIndex + 1, colToNormalize + "_z");
            String headerString = String.join(",", header);
            writeCSV((headerString), destPath);

            BigDecimal mean = scoringSummary.mean();
            BigDecimal SD = scoringSummary.standardDeviation();

            // calculate z-score for each row element
            ArrayList<BigDecimal> zScore = new ArrayList<>();
            for (int i = 1; i < columnData.size(); i++) {
                BigDecimal rowBigDecimal = BigDecimal.valueOf((Double.parseDouble(columnData.get(i))));
                BigDecimal rowZScore = (rowBigDecimal.subtract(mean)).divide(SD, 2, RoundingMode.HALF_EVEN);
                zScore.add(rowZScore);
            }

            for (int i = 1; i < allColumnsData.size(); i++) {
                ArrayList<String> rowArrayList = new ArrayList<>(Arrays.asList(allColumnsData.get(i)));
                rowArrayList.add(columnIndex + 1, String.valueOf(zScore.get(i - 1)));
                String rowString = String.join(",", rowArrayList);
                writeCSV((rowString), destPath);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return scoringSummary;
    }

    @Override
    public ScoringSummary minMaxScaling(Path csvPath, Path destPath, String colToNormalize) {

        ScoringSummary scoringSummary = new ScoringSummaryClass(csvPath, destPath, colToNormalize);
        try {
            JSONObject result = readCSV(csvPath, colToNormalize);
            ArrayList<String> columnData = (ArrayList<String>) result.get("columnData");
            ArrayList<String[]> allColumnsData = ((ArrayList<String[]>) result.get("allColumnsData"));
            String[] CSVFileHeader = allColumnsData.get(0);
            int columnIndex = (int) result.get("columnIndex");


            ArrayList<String> header = new ArrayList<>(Arrays.asList(CSVFileHeader));
            header.add(columnIndex + 1, colToNormalize + "_mm");
            String headerString = String.join(",", header);
            writeCSV((headerString), destPath);

            BigDecimal min = scoringSummary.min();
            BigDecimal max = scoringSummary.max();

            ArrayList<BigDecimal> minMaxScaling = new ArrayList<>();
            for (int i = 1; i < columnData.size(); i++) {
                BigDecimal rowBigDecimal = BigDecimal.valueOf((Double.parseDouble(columnData.get(i))));
                BigDecimal minTemp = rowBigDecimal.subtract(min);
                BigDecimal maxTemp = max.subtract(min);
                minMaxScaling.add(minTemp.divide(maxTemp, 2, RoundingMode.HALF_EVEN));
            }

            for (int i = 1; i < allColumnsData.size(); i++) {
                ArrayList<String> rowArrayList = new ArrayList<>(Arrays.asList(allColumnsData.get(i)));
                rowArrayList.add(columnIndex + 1, String.valueOf(minMaxScaling.get(i - 1)));
                String rowString = String.join(",", rowArrayList);
                writeCSV((rowString), destPath);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return scoringSummary;
    }


}
